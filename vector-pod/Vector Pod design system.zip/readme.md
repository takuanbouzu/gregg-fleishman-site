# Vector Pod — Design System

A dark **engineering-instrument** design language, extracted verbatim from the
*Vector Pod — Interactive Part Study*: a single-screen, real-time 3D study of
one of Gregg Fleishman's unpublished modular-pod explorations. The interface
behaves like a precision measuring tool — calm, dimmed, monospace-annotated —
so the geometry on screen is the only thing that ever feels "bright."

**Source:** `github.com/takuanbouzu/gregg-fleishman-site` → `/vector-pod/`
(built with React + a Tailwind/shadcn base layer; the instrument styling sits
on top of that as a bespoke layer). All tokens here are lifted directly from
the shipped `assets/index-*.css`.

---

## The idea in one line
> A near-black cool void, warm parchment ink, **one** terracotta accent, two
> diagnostic signal lights, and monospace micro-labels on everything — assembled
> from sharp-cornered glass panels floating on deep soft shadows.

---

## CONTENT FUNDAMENTALS

How the instrument writes:

- **Voice:** clipped, technical, captioning. It labels rather than explains.
  Copy reads like the side of a scientific instrument: `PART STUDY · 01`,
  `EXPLODE`, `SOURCE: UNPUBLISHED`, `READY`.
- **Casing:** two registers only — `UPPERCASE` for mono micro-labels (eyebrows,
  indices, status, dock buttons, categories) and sentence/`Title Case` for the
  few sans headings. Never ALL-CAPS in the sans family.
- **Tracking is meaning.** The wider the letter-spacing, the smaller and more
  "system" the text. Panel labels ride at `0.2em`; status text at `0.08em`.
- **Person:** impersonal. No "you", no "we". It states conditions, not actions
  ("READY", "12 PARTS"), not instructions ("Click to…").
- **Numbers & indices** are first-class. Modes are numbered (`01`, `02`),
  readouts are dense definition lists, counts are shown bare.
- **No emoji. Ever.** No exclamation. The tone is composed and quiet — the
  product's only excitement is the object being studied.
- **Examples:** `VECTOR POD`, `INTERACTIVE PART STUDY`, `LAYERS`, `EXPLODE 0.0×`,
  `MATERIAL · BIRCH PLY`, `STATUS: READY`, `SOURCE NOTE — UNPUBLISHED, c. 1978`.

---

## VISUAL FOUNDATIONS

**Color.** A cool near-black ground (`#070a0b`) under warm parchment ink
(`#e5e0d4`). Exactly **one** chromatic accent — terracotta `#db684d` — used
sparingly as the active/identity signal (the masthead tick, the active rail bar,
the loading mark). Two diagnostic colors only appear as small dots: ready-green
`#77a485` and idle-rust `#855349`. Everything else is a graded warm-grey ramp
(`#939b96 → #56605b`). The accent is never used as a fill for large areas —
it's a 1px line, a 7px dot, a 2px inset bar.

**Type.** Avenir Next (light, 300–500) for the few headings and the giant
masthead; a system **monospace** for all micro-labeling. The display headline is
huge, hairline-light (weight 300), and negatively tracked (`-0.052em`); the mono
labels are tiny (8–11px) and widely tracked (`0.08–0.2em`). See `tokens/typography.css`.

**Geometry — sharp.** This is the defining trait: panels, buttons, rails and the
dock are **rectangles with no corner radius**. The *only* rounded things in the
entire system are full circles — signal swatches, the slider thumb, status dots.
Don't introduce `border-radius` on containers.

**Surfaces, transparency & blur.** Panels are translucent dark glass
(`rgba(9,13,14,0.76)`) with an **18px backdrop-blur** and a single hairline
border (`rgba(198,205,198,0.16)`). They are fixed to the viewport corners and
float on deep, far, soft shadows (`0 24px 70px rgba(0,0,0,.26)`). Blur is used
everywhere a panel overlaps the live 3D scene — it's structural, not decorative.

**Texture.** A faint fractal-noise grain overlays the whole scene at `0.13`
opacity with `mix-blend-mode: soft-light` — it warms the void and kills banding.
No gradients anywhere (the void is flat); no images in chrome.

**Borders & rules.** Hairlines do all the dividing — 1px `rgba(198,205,198,.16)`
between rows and around panels, plus tiny solid `#303836` rule segments in the
status bar. The active state on the mode rail is a 2px **inset** accent bar
(`box-shadow: inset 2px 0 var(--accent)`), not a background fill.

**Motion.** Quiet and short. Control hovers cross-fade color + background in
~160ms; panels show/hide in ~180ms with a small 12px translate. The one signature
animation is the loading mark: a hairline square that slowly rotates 45°→135° and
scales down on a 1.3s ease-in-out heartbeat, shifting from grey to terracotta.
Respects `prefers-reduced-motion`.

**Hover / press.** Hover = lift toward brighter ink (`#7f8783 → #ede8da`) plus a
4–5% white veil. Active controls gain the inset accent bar. Disabled / idle
controls simply lose opacity. There are no scale-down press states in the chrome.

**Layout.** A full-bleed scene with chrome pinned to the four edges: masthead
top-left, mode rail mid-left, layer/inspector panel top-right, view dock bottom-
center, status bar along the bottom. Panels are fixed-width (205 / 248 / 274px),
the canvas is everything behind them. Generous insets from the viewport edge
(38–40px desktop, 10–22px mobile).

---

## ICONOGRAPHY

- The instrument uses **simple line icons** at small sizes (`size-4` ≈ 16px,
  thin stroke) — the React app ships **Lucide** (the shadcn default). For
  recreations, link Lucide from CDN and keep strokes thin and monochrome,
  inheriting `currentColor` so they read as muted grey until hover.
- Icons are always paired with mono labels and indices; they're never the sole
  affordance. The active/identity color (terracotta) is reserved for the accent
  rule, not icons.
- The repo's `icons.svg` sprite only contains **social glyphs** (GitHub, X,
  Bluesky, Discord) for the parent site — not part of the instrument UI, so they
  are not bundled here.
- `assets/parent-mark.svg` is the *parent* Gregg-Fleishman-site logo (a purple
  geometric glyph). It is kept for provenance only — it is **off-palette** for
  this instrument system; do not use it as the Vector Pod mark. The instrument's
  own mark is the rotating hairline **diamond** (see the loading state / brand
  card), rendered in terracotta.
- **No emoji, no unicode-as-icon.**

---

## INDEX / MANIFEST

```
styles.css                  → @import manifest (link this)
tokens/
  colors.css                → instrument palette + semantic aliases
  typography.css            → sans + mono voices, weight & tracking scales
  spacing.css               → spacing, sharp geometry, motion, texture
guidelines/                 → foundation specimen cards (Design System tab)
components/instrument/       → reusable React primitives + cards
ui_kits/part-study/          → full Vector-Pod instrument screen recreation
assets/parent-mark.svg       → parent-site logo (provenance only)
SKILL.md                     → portable skill wrapper
```

**Components** (`components/instrument/`): `GlassPanel`, `PanelLabel`,
`ModeButton`, `ToggleRow`, `InstrumentSlider`, `ViewDock`, `StatusBar`,
`StatusDot`, `Readout`, `Button`, `Badge`, `BrandMark`.

**UI kit** (`ui_kits/part-study/`): the assembled instrument — masthead, mode
rail, layer panel / part inspector, view dock, status bar over a placeholder
scene.

---

*Sharing note: set the file type to **Design System** in the Share menu so your
org can use this.*
