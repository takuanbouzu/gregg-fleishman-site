StatusBar is the bottom-edge micro-readout strip — mono uppercase segments joined by tiny rules, with an optional leading dot and right-aligned note.

```jsx
<StatusBar dot="ready" segments={["Vector Pod", "12 Parts", "Birch Ply"]}
  note="Source: Unpublished" />
```
