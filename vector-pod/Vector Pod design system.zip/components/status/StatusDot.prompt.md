StatusDot is a 5px diagnostic light — use inline to signal ready/idle/accent state.

```jsx
<StatusDot tone="ready" />
```
