ViewDock is the centered floating toolbar for view presets — segmented mono buttons with thin rule separators.

```jsx
<ViewDock value={view} onChange={setView} options={[
  { id: "front", label: "Front" },
  { id: "top", label: "Top" },
  { rule: true },
  { id: "iso", label: "ISO" },
]} />
```
