import React, { useState } from "react";

/**
 * ViewDock — a centered, floating glass toolbar (sharp, blurred, hairline).
 * Holds segmented options separated by thin vertical rules; the active option
 * lights to parchment. Use for view presets (Front / Top / ISO …).
 */
export function ViewDock({ options = [], value, onChange, style, ...rest }) {
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: 5,
        background: "var(--panel-glass-strong)",
        border: "1px solid var(--hairline)",
        backdropFilter: "blur(18px)",
        WebkitBackdropFilter: "blur(18px)",
        boxShadow: "var(--shadow-dock)",
        ...style,
      }}
      {...rest}
    >
      {options.map((opt, i) => (
        <React.Fragment key={opt.id ?? i}>
          {opt.rule ? (
            <span
              style={{
                width: 1,
                height: 22,
                margin: "0 3px",
                background: "var(--hairline)",
              }}
            />
          ) : (
            <DockButton
              active={value === opt.id}
              onClick={() => onChange && onChange(opt.id)}
              icon={opt.icon}
              label={opt.label}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function DockButton({ active, onClick, icon, label }) {
  const [hover, setHover] = useState(false);
  const lit = active || hover;
  return (
    <button
      type="button"
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 7,
        minWidth: 74,
        height: 34,
        padding: "0 9px",
        background: lit ? "rgba(255,255,255,0.05)" : "transparent",
        border: 0,
        color: lit ? "var(--ink-bright)" : "var(--muted-4)",
        fontFamily: "var(--font-mono)",
        fontSize: 9,
        letterSpacing: "0.1em",
        textTransform: "uppercase",
        cursor: "pointer",
        transition: "color 0.16s var(--ease), background 0.16s var(--ease)",
      }}
    >
      {icon != null ? <span style={{ display: "inline-flex" }}>{icon}</span> : null}
      {label}
    </button>
  );
}
