import React from "react";

const TONES = {
  ready: "var(--signal-ready)",
  idle: "var(--signal-idle)",
  accent: "var(--accent)",
  neutral: "var(--muted-4)",
};

/**
 * StatusDot — a 5px diagnostic light. Ready/accent dots glow; idle/neutral
 * are flat. Use inline in the status bar or beside a label.
 */
export function StatusDot({ tone = "idle", size = 5, glow, style, ...rest }) {
  const color = TONES[tone] || TONES.idle;
  const shouldGlow = glow != null ? glow : tone === "ready" || tone === "accent";
  return (
    <span
      style={{
        display: "inline-block",
        width: size,
        height: size,
        borderRadius: "50%",
        background: color,
        boxShadow: shouldGlow ? `0 0 9px ${color}` : "none",
        ...style,
      }}
      {...rest}
    />
  );
}
