import * as React from "react";

export interface StatusBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional leading status dot tone. */
  dot?: "ready" | "idle" | "accent" | "neutral";
  /** Mono uppercase segments, joined by tiny rules. */
  segments: React.ReactNode[];
  /** Right-aligned note (e.g. a source credit). */
  note?: React.ReactNode;
}

/** The bottom-edge micro-readout strip: dot + rule-separated mono segments + note. */
export function StatusBar(props: StatusBarProps): JSX.Element;
