import * as React from "react";

export interface ViewDockOption {
  id?: string;
  label?: React.ReactNode;
  icon?: React.ReactNode;
  /** Render a vertical rule instead of a button. */
  rule?: boolean;
}

export interface ViewDockProps extends React.HTMLAttributes<HTMLDivElement> {
  options: ViewDockOption[];
  /** Currently selected option id. */
  value?: string;
  onChange?: (id: string) => void;
}

/** Centered floating glass toolbar of segmented view presets. */
export function ViewDock(props: ViewDockProps): JSX.Element;
