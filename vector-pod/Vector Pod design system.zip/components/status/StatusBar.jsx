import React from "react";
import { StatusDot } from "./StatusDot.jsx";

/**
 * StatusBar — the micro-readout strip along the bottom edge. A row of mono,
 * uppercase, widely-tracked segments separated by tiny solid rules, with an
 * optional leading status dot and a right-aligned source note.
 */
export function StatusBar({ dot, segments = [], note, style, ...rest }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        fontFamily: "var(--font-mono)",
        fontSize: 8,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        color: "var(--muted-6)",
        ...style,
      }}
      {...rest}
    >
      {dot ? <StatusDot tone={dot} /> : null}
      {segments.map((seg, i) => (
        <React.Fragment key={i}>
          {i > 0 ? (
            <span
              style={{
                width: 26,
                height: 1,
                background: "var(--rule)",
                display: "inline-block",
              }}
            />
          ) : null}
          <span>{seg}</span>
        </React.Fragment>
      ))}
      {note ? <span style={{ marginLeft: "auto" }}>{note}</span> : null}
    </div>
  );
}
