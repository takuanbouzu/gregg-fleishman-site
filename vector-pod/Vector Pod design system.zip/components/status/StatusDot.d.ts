import * as React from "react";

export interface StatusDotProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: "ready" | "idle" | "accent" | "neutral";
  /** Diameter in px (default 5). */
  size?: number;
  /** Force the glow on/off (defaults: ready & accent glow). */
  glow?: boolean;
}

/** A 5px diagnostic light; ready/accent glow, idle/neutral are flat. */
export function StatusDot(props: StatusDotProps): JSX.Element;
