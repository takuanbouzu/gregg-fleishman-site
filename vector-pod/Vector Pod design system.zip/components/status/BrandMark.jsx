import React from "react";

/**
 * BrandMark — the instrument's identity: a hairline square rotated 45° into a
 * diamond. When `animated`, it runs the signature 1.3s heartbeat (rotate +
 * shrink, grey → terracotta). Respects prefers-reduced-motion via the keyframe
 * being inert when animation is off.
 */
export function BrandMark({ size = 43, animated = false, color = "#3b4541", style, ...rest }) {
  const name = "vp-pulse-mark";
  return (
    <span style={{ display: "inline-grid", placeItems: "center", ...style }} {...rest}>
      <style>{`
        @keyframes ${name}{to{border-color:var(--accent-deep);transform:rotate(135deg) scale(0.72);}}
        @media (prefers-reduced-motion: reduce){.${name}-el{animation:none !important;}}
      `}</style>
      <span
        className={`${name}-el`}
        style={{
          width: size,
          height: size,
          border: `1px solid ${color}`,
          transform: "rotate(45deg)",
          animation: animated ? `${name} 1.3s ease-in-out infinite alternate` : "none",
        }}
      />
    </span>
  );
}
