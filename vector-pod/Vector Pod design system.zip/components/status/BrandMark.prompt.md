BrandMark is the instrument's identity — a hairline diamond. Use it static as a logo, or `animated` for the loading heartbeat.

```jsx
<BrandMark animated />
<BrandMark size={20} />
```
