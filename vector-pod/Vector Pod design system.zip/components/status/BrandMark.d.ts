import * as React from "react";

export interface BrandMarkProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Square edge length in px (default 43). */
  size?: number;
  /** Run the 1.3s heartbeat (rotate + shrink, grey → terracotta). */
  animated?: boolean;
  /** Resting border color (default #3b4541). */
  color?: string;
}

/** The hairline-diamond identity mark, optionally on its loading heartbeat. */
export function BrandMark(props: BrandMarkProps): JSX.Element;
