import React, { useState } from "react";

/**
 * Button — instrument-grade, mostly outline/ghost (this system rarely fills).
 * Sharp corners, mono uppercase for technical actions. Variants:
 *  - ghost  : transparent, muted ink → parchment + faint veil on hover (default)
 *  - dock   : view-dock style (mono, min-width, centered)
 *  - accent : terracotta hairline outline for the one primary action
 */
export function Button({
  variant = "ghost",
  active = false,
  icon,
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const lit = active || hover;

  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    border: 0,
    borderRadius: 0,
    cursor: "pointer",
    fontFamily: "var(--font-mono)",
    transition: "color 0.16s var(--ease), background 0.16s var(--ease), border-color 0.16s var(--ease)",
  };

  const variants = {
    ghost: {
      height: 34,
      padding: "0 12px",
      fontSize: 11,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      background: lit ? "var(--hover-veil-strong)" : "transparent",
      color: lit ? "var(--ink-bright)" : "var(--muted-4)",
    },
    dock: {
      minWidth: 74,
      height: 34,
      padding: "0 9px",
      fontSize: 9,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      background: lit ? "rgba(255,255,255,0.05)" : "transparent",
      color: lit ? "var(--ink-bright)" : "var(--muted-4)",
    },
    accent: {
      height: 34,
      padding: "0 16px",
      fontSize: 11,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      background: hover ? "var(--accent-wash-10)" : "transparent",
      color: active || hover ? "var(--accent-bright)" : "var(--accent)",
      boxShadow: "inset 0 0 0 1px var(--accent)",
    },
  };

  return (
    <button
      type="button"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ ...base, ...variants[variant], ...style }}
      {...rest}
    >
      {icon != null ? <span style={{ display: "inline-flex" }}>{icon}</span> : null}
      {children}
    </button>
  );
}
