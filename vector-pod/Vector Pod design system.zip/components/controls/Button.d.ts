import * as React from "react";

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** ghost (default) · dock (view-dock) · accent (terracotta outline). */
  variant?: "ghost" | "dock" | "accent";
  /** Active/selected — keeps the lit state without hover. */
  active?: boolean;
  /** Optional leading icon. */
  icon?: React.ReactNode;
}

/** Instrument button — mostly outline/ghost, mono uppercase, sharp corners. */
export function Button(props: ButtonProps): JSX.Element;
