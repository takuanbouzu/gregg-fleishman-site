Button is the instrument action control — default `ghost`, `dock` for the bottom toolbar, `accent` for the single primary action. Mono uppercase, sharp corners.

```jsx
<Button variant="dock" active>Front</Button>
<Button variant="accent">Reset View</Button>
```
