import * as React from "react";

export interface InstrumentSliderProps {
  /** Mono label shown top-left. */
  label: React.ReactNode;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  /** Formatted value shown top-right (defaults to raw value), e.g. "1.4×". */
  display?: React.ReactNode;
  /** Dims the whole control to 0.32 opacity (the disabled explode state). */
  disabled?: boolean;
  onChange?: (value: number) => void;
  style?: React.CSSProperties;
}

/** Labeled range: mono heading row over a 2px track with a tiny circular thumb. */
export function InstrumentSlider(props: InstrumentSliderProps): JSX.Element;
