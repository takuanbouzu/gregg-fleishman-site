import * as React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Maps to the signal palette. */
  tone?: "neutral" | "ready" | "idle" | "accent";
  /** Show a leading glowing signal dot. */
  dot?: boolean;
}

/** Sharp hairline tag for status/metadata, with an optional signal dot. */
export function Badge(props: BadgeProps): JSX.Element;
