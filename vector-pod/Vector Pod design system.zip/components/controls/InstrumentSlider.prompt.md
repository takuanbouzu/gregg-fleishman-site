InstrumentSlider is the system's range control — use it for continuous parameters like explode distance or opacity. Provide a formatted `display` for the right-hand readout.

```jsx
<InstrumentSlider label="Explode" value={v} min={0} max={2} step={0.1}
  display={`${v.toFixed(1)}×`} onChange={setV} />
```

Set `disabled` to dim the whole control (the idle explode state).
