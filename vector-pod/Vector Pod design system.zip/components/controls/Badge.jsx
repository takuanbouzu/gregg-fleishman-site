import React from "react";

const TONES = {
  neutral: { color: "var(--muted-3)", dot: "var(--muted-4)" },
  ready: { color: "var(--signal-ready)", dot: "var(--signal-ready)" },
  idle: { color: "var(--signal-idle)", dot: "var(--signal-idle)" },
  accent: { color: "var(--accent)", dot: "var(--accent)" },
};

/**
 * Badge — a sharp hairline tag for status/metadata. Mono, uppercase, tiny,
 * with an optional glowing signal dot. Four tones map to the signal palette.
 */
export function Badge({ tone = "neutral", dot = false, children, style, ...rest }) {
  const t = TONES[tone] || TONES.neutral;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 7,
        height: 20,
        padding: "0 8px",
        border: "1px solid var(--hairline)",
        background: "transparent",
        color: t.color,
        fontFamily: "var(--font-mono)",
        fontSize: 9,
        letterSpacing: "0.14em",
        textTransform: "uppercase",
        ...style,
      }}
      {...rest}
    >
      {dot ? (
        <span
          style={{
            width: 5,
            height: 5,
            borderRadius: "50%",
            background: t.dot,
            boxShadow: tone !== "neutral" ? `0 0 8px ${t.dot}` : "none",
          }}
        />
      ) : null}
      {children}
    </span>
  );
}
