import * as React from "react";

export interface ToggleRowProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "onToggle"> {
  /** Primary label (strong, 11px). */
  strong: React.ReactNode;
  /** Faint secondary caption below the label. */
  small?: React.ReactNode;
  /** CSS color for the glowing signal swatch (default terracotta). */
  colorDot?: string;
  /** Pressed/visible state — drives aria-pressed and full-opacity swatch. */
  pressed?: boolean;
  /** Trailing node, typically a visibility (eye) icon. */
  trailing?: React.ReactNode;
  onToggle?: () => void;
}

/** A layer/visibility row: signal swatch + two-line copy + trailing icon. */
export function ToggleRow(props: ToggleRowProps): JSX.Element;
