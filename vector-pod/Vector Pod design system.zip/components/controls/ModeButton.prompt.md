ModeButton is a row in the left mode rail — use it to switch between exclusive instrument modes. Give the active one `active` for the inset terracotta bar.

```jsx
<ModeButton index="01" label="Assembled" active />
<ModeButton index="02" label="Exploded" />
```
