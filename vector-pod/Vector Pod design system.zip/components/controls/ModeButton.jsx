import React, { useState } from "react";

/**
 * ModeButton — a row in the mode rail. Mono index + optional icon + label,
 * with the signature active state: brighter ink, a faint white veil, and a
 * 2px inset terracotta bar on the leading edge. Sharp corners, hairline top.
 */
export function ModeButton({
  index,
  icon,
  label,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const lit = active || hover;
  return (
    <button
      type="button"
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "grid",
        gridTemplateColumns: `${index != null ? "27px " : ""}${
          icon != null ? "22px " : ""
        }1fr`,
        alignItems: "center",
        gap: 7,
        width: "100%",
        minHeight: 42,
        padding: "0 8px",
        textAlign: "left",
        background: lit ? "var(--hover-veil)" : "transparent",
        border: 0,
        borderTop: "1px solid var(--hairline-soft)",
        color: lit ? "var(--ink-bright)" : "var(--muted-3)",
        boxShadow: active ? "inset 2px 0 var(--accent)" : "none",
        cursor: "pointer",
        transition: "color 0.16s var(--ease), background 0.16s var(--ease)",
        fontFamily: "var(--font-sans)",
        ...style,
      }}
      {...rest}
    >
      {index != null ? (
        <span
          style={{
            color: "var(--muted-7)",
            fontFamily: "var(--font-mono)",
            fontSize: 9,
            letterSpacing: "0.04em",
          }}
        >
          {index}
        </span>
      ) : null}
      {icon != null ? (
        <span style={{ display: "inline-flex", color: "inherit" }}>{icon}</span>
      ) : null}
      <span style={{ fontSize: 12, letterSpacing: "0.02em" }}>{label}</span>
    </button>
  );
}
