Badge is a sharp hairline tag for status and metadata, with an optional glowing signal dot.

```jsx
<Badge tone="ready" dot>Ready</Badge>
<Badge tone="neutral">12 Parts</Badge>
```
