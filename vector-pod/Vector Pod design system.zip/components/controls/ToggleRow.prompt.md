ToggleRow is a layer/visibility toggle with a glowing signal swatch — use it in a layer panel to show/hide groups.

```jsx
<ToggleRow strong="Frame" small="6 struts" colorDot="var(--accent)" pressed onToggle={fn} />
```

Pass `trailing` an eye icon. `pressed` drives `aria-pressed` and the full-opacity swatch.
