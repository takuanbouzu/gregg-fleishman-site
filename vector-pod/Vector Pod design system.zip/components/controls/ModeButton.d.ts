import * as React from "react";

export interface ModeButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  /** Mono index shown at the leading edge, e.g. "01". */
  index?: React.ReactNode;
  /** Optional leading icon (≈16px, thin stroke, inherits color). */
  icon?: React.ReactNode;
  /** Control label. */
  label: React.ReactNode;
  /** Active mode — adds the 2px inset terracotta bar + brighter ink. */
  active?: boolean;
}

/** A row in the mode rail: index + icon + label, with the inset-accent active state. */
export function ModeButton(props: ModeButtonProps): JSX.Element;
