import React, { useId } from "react";

/**
 * InstrumentSlider — a labeled range. A mono heading row (label left, value
 * right) over a 2px track with a tiny circular thumb (dark fill, parchment
 * edge). The whole control dims when disabled, matching the explode control.
 */
export function InstrumentSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  display,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const id = useId().replace(/:/g, "");
  const cls = `vp-range-${id}`;
  return (
    <div
      style={{
        opacity: disabled ? 0.32 : 1,
        transition: "opacity 0.18s var(--ease)",
        ...style,
      }}
    >
      <style>{`
        .${cls}{appearance:none;-webkit-appearance:none;width:100%;height:2px;background:var(--track);border-radius:0;outline:none;cursor:${
          disabled ? "default" : "ew-resize"
        };}
        .${cls}::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:9px;height:9px;border-radius:50%;background:var(--panel);border:1px solid var(--ink-warm);cursor:${
        disabled ? "default" : "ew-resize"
      };}
        .${cls}::-moz-range-thumb{width:9px;height:9px;border-radius:50%;background:var(--panel);border:1px solid var(--ink-warm);cursor:${
        disabled ? "default" : "ew-resize"
      };}
      `}</style>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom: 10,
          fontFamily: "var(--font-mono)",
          fontSize: 9,
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          color: "var(--muted-3)",
        }}
      >
        <span>{label}</span>
        <strong style={{ color: "var(--ink-soft)", fontWeight: 500 }}>
          {display != null ? display : value}
        </strong>
      </div>
      <input
        type="range"
        className={cls}
        value={value}
        min={min}
        max={max}
        step={step}
        disabled={disabled}
        onChange={(e) => onChange && onChange(Number(e.target.value))}
        {...rest}
      />
    </div>
  );
}
