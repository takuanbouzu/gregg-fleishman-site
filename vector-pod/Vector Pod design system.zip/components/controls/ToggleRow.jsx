import React, { useState } from "react";

/**
 * ToggleRow — a layer/visibility row: a glowing signal swatch, a two-line copy
 * block (strong label + faint caption), and a trailing visibility icon. Lifts
 * toward parchment ink when hovered or pressed. Uses aria-pressed for state.
 */
export function ToggleRow({
  strong,
  small,
  colorDot = "var(--accent)",
  pressed = false,
  onToggle,
  trailing,
  style,
  ...rest
}) {
  const [hover, setHover] = useState(false);
  const lit = pressed || hover;
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onToggle}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "grid",
        gridTemplateColumns: "9px 1fr 16px",
        alignItems: "center",
        gap: 10,
        width: "100%",
        minHeight: 46,
        padding: "5px 3px",
        textAlign: "left",
        background: "transparent",
        border: 0,
        color: lit ? "var(--ink)" : "var(--muted-2)",
        cursor: "pointer",
        transition: "color 0.16s var(--ease)",
        fontFamily: "var(--font-sans)",
        ...style,
      }}
      {...rest}
    >
      <span
        style={{
          width: 7,
          height: 7,
          borderRadius: "50%",
          background: colorDot,
          boxShadow: `0 0 10px ${colorDot}`,
          opacity: pressed ? 1 : 0.85,
        }}
      />
      <span style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        <strong style={{ fontWeight: 500, fontSize: 11, letterSpacing: "0.03em" }}>
          {strong}
        </strong>
        {small ? (
          <small style={{ color: "var(--muted-5)", fontSize: 9 }}>{small}</small>
        ) : null}
      </span>
      <span style={{ display: "inline-flex", opacity: 0.7, justifySelf: "end" }}>
        {trailing}
      </span>
    </button>
  );
}
