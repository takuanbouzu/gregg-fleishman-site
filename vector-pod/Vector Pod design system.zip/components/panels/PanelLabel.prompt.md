PanelLabel is the instrument's smallest text voice — a monospace, uppercase, widely-tracked micro-label used to title panels and sections.

```jsx
<PanelLabel>Materials</PanelLabel>
```
