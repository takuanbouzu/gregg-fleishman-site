import * as React from "react";

export interface PanelLabelProps
  extends React.HTMLAttributes<HTMLParagraphElement> {
  children?: React.ReactNode;
}

/** Monospace micro-label: uppercase, 9px, 0.2em tracking, muted grey. */
export function PanelLabel(props: PanelLabelProps): JSX.Element;
