import React from "react";

/**
 * PanelLabel — the instrument's smallest voice: a monospace micro-label,
 * uppercase and widely tracked, used to title panels and sections.
 */
export function PanelLabel({ children, style, ...rest }) {
  return (
    <p
      style={{
        margin: 0,
        color: "var(--muted-4)",
        fontFamily: "var(--font-mono)",
        fontSize: 9,
        letterSpacing: "0.2em",
        textTransform: "uppercase",
        ...style,
      }}
      {...rest}
    >
      {children}
    </p>
  );
}
