GlassPanel is the core floating surface for all instrument chrome — translucent dark glass with hairline border and 18px blur; use it for any side panel, rail, or inspector that overlays the scene.

```jsx
<GlassPanel label="Layers" heading="Components" width={248}>
  <ToggleRow strong="Frame" small="6 struts" colorDot="var(--accent)" />
</GlassPanel>
```

Pair with `PanelLabel` for sub-section labels inside, and `Readout` for technical detail lists. Keep corners sharp (radius 0) and width fixed.
