import React from "react";
import { PanelLabel } from "./PanelLabel.jsx";

/**
 * GlassPanel — the core surface. A sharp-cornered, translucent dark-glass
 * container with an 18px backdrop blur, a single hairline border, and a deep
 * soft shadow. Optionally renders a mono label and a sans heading row.
 */
export function GlassPanel({
  label,
  heading,
  headingAccessory,
  width,
  children,
  style,
  ...rest
}) {
  return (
    <section
      style={{
        width,
        background: "var(--panel-glass)",
        border: "1px solid var(--hairline)",
        backdropFilter: "blur(18px)",
        WebkitBackdropFilter: "blur(18px)",
        boxShadow: "var(--shadow-panel)",
        padding: "18px 17px 15px",
        fontFamily: "var(--font-sans)",
        ...style,
      }}
      {...rest}
    >
      {label ? (
        <PanelLabel style={{ marginBottom: heading ? 12 : 0 }}>{label}</PanelLabel>
      ) : null}
      {heading ? (
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <h2
            style={{
              margin: 0,
              color: "var(--ink-strong)",
              fontWeight: 450,
              fontSize: 15,
            }}
          >
            {heading}
          </h2>
          {headingAccessory ? (
            <span style={{ color: "var(--muted-4)", display: "inline-flex" }}>
              {headingAccessory}
            </span>
          ) : null}
        </div>
      ) : null}
      {children}
    </section>
  );
}
