Readout renders a dense, hairline-divided definition list — use it for the part inspector or any technical key/value detail block.

```jsx
<Readout items={[
  { label: "Material", value: "Birch Ply" },
  { label: "Count", value: "12 parts" },
]} />
```
