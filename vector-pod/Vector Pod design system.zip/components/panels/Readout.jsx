import React from "react";

/**
 * Readout — a dense technical definition list (the part inspector's body).
 * Each row is a hairline-topped grid of a muted mono term and a parchment value.
 */
export function Readout({ items = [], termWidth = 70, style }) {
  return (
    <dl style={{ margin: 0, ...style }}>
      {items.map((it, i) => (
        <div
          key={i}
          style={{
            display: "grid",
            gridTemplateColumns: `${termWidth}px 1fr`,
            gap: 12,
            padding: "8px 0",
            borderTop: "1px solid var(--hairline-soft)",
            fontFamily: "var(--font-mono)",
            fontSize: 10,
          }}
        >
          <dt
            style={{
              color: "var(--muted-5)",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            {it.label}
          </dt>
          <dd
            style={{
              margin: 0,
              color: "var(--ink-detail)",
              overflowWrap: "anywhere",
            }}
          >
            {it.value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
