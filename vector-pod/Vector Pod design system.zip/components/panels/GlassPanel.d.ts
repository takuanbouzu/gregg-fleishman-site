import * as React from "react";

export interface GlassPanelProps extends React.HTMLAttributes<HTMLElement> {
  /** Mono micro-label shown at the top (uppercase, 0.2em tracking). */
  label?: React.ReactNode;
  /** Sans heading row below the label. */
  heading?: React.ReactNode;
  /** Optional node (e.g. an icon) pinned to the right of the heading. */
  headingAccessory?: React.ReactNode;
  /** Fixed panel width, e.g. 248 or "248px". Instrument panels are fixed-width. */
  width?: number | string;
  children?: React.ReactNode;
}

/**
 * The core instrument surface: sharp-cornered translucent dark glass with an
 * 18px backdrop blur, hairline border, and deep soft shadow. Never round it.
 */
export function GlassPanel(props: GlassPanelProps): JSX.Element;
