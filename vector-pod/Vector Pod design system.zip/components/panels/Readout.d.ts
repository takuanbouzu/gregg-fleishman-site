import * as React from "react";

export interface ReadoutItem {
  label: React.ReactNode;
  value: React.ReactNode;
}

export interface ReadoutProps {
  /** Ordered term/value pairs. Each renders a hairline-topped row. */
  items: ReadoutItem[];
  /** Width of the term column in px (default 70). */
  termWidth?: number;
  style?: React.CSSProperties;
}

/** Dense technical definition list — the part inspector's body. */
export function Readout(props: ReadoutProps): JSX.Element;
