---
name: vector-pod-design
description: Use this skill to generate well-branded interfaces and assets in the Vector Pod "engineering instrument" design language — a dark, near-black UI with warm parchment ink, a single terracotta accent, monospace micro-labels, and sharp-cornered glass panels. Good for production UI or throwaway prototypes, mocks, and decks. Contains colors, type, geometry tokens, reusable React components, and a full instrument UI kit.
user-invocable: true
---

Read `readme.md` first — it carries the full design guide: content/voice rules,
visual foundations, iconography, and a file manifest. Then explore:

- `styles.css` → link this one file to inherit every token.
- `tokens/` → colors, typography, spacing/geometry/motion custom properties.
- `guidelines/` → foundation specimen cards (colors, type, geometry, brand).
- `components/instrument` (panels / controls / status) → reusable React primitives.
- `ui_kits/part-study/index.html` → the assembled, interactive instrument screen.

Core rules to honor:
- One accent only (terracotta `#db684d`); never fill large areas with it.
- Sharp corners everywhere (radius 0); the ONLY rounded forms are circle dots.
- Monospace, uppercase, widely-tracked micro-labels; light sans for the few headings.
- Translucent dark-glass panels (18px blur, hairline border, deep soft shadow).
- Quiet, short motion; no emoji; impersonal, instrument-caption copy.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy assets
out and produce static HTML for the user to view. If working in production code,
copy assets and apply the rules here. If invoked with no other guidance, ask the
user what they want to build, ask a few focused questions, then act as an expert
designer producing HTML artifacts or production code as needed.
